"use client";
import React, { useState } from "react";
import {
  FaStar, FaPen, FaList, FaUser, FaCalendarAlt, FaTags, FaImage, FaCheckCircle
} from "react-icons/fa";

export default function AddReviewPage() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    author: "",
    date: "",
    rating: 0,
    authorImg: "",
  });

  const [status, setStatus] = useState(null);
  const [statusType, setStatusType] = useState("");
  const [hoverRating, setHoverRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    // Clear error messages when user starts typing
    if (status && statusType === "error") {
      setStatus(null);
    }
  };

  const handleRatingChange = (rating) => {
    setForm({ ...form, rating });
    // Clear error messages when user sets rating
    if (status && statusType === "error") {
      setStatus(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.rating) {
      setStatus("กรุณาให้คะแนนก่อนส่ง");
      setStatusType("error");
      return;
    }

    setIsSubmitting(true);

    // ถ้าไม่ได้ใส่ authorImg ให้สร้างแบบสุ่มจากชื่อผู้เขียน
    const formDataToSend = {
      ...form,
      authorImg:
        form.authorImg ||
        `https://i.pravatar.cc/150?u=${encodeURIComponent(form.author)}`,
    };

    try {
      const res = await fetch("/api/review", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formDataToSend),
      });

      const data = await res.json();
      if (data.success) {
        setStatus("ส่งรีวิวเรียบร้อยแล้ว! ขอบคุณสำหรับความคิดเห็นของคุณ");
        setStatusType("success");
        setForm({
          title: "",
          description: "",
          category: "",
          author: "",
          date: "",
          rating: 0,
          authorImg: "",
        });
        setHoverRating(0);
        
        // Scroll to top to see success message
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setStatus(data.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง");
        setStatusType("error");
      }
    } catch (error) {
      console.error(error);
      setStatus("ไม่สามารถส่งรีวิวได้ กรุณาลองใหม่");
      setStatusType("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStarRating = () => (
    <div className="flex items-center space-x-2">
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <FaStar
            key={star}
            className={`text-2xl cursor-pointer transition-colors ${
              star <= (hoverRating || form.rating)
                ? "text-yellow-400"
                : "text-gray-300"
            } hover:scale-110 transition-transform`}
            onClick={() => handleRatingChange(star)}
            onMouseEnter={() => setHoverRating(star)}
            onMouseLeave={() => setHoverRating(0)}
          />
        ))}
      </div>
      {form.rating > 0 && (
        <span className="text-sm font-medium text-gray-800 ml-2">{form.rating}/5</span>
      )}
    </div>
  );

  const categories = [
    "Study", "Environment", "Experience","Other",
  ];

  const isSubmitDisabled = !form.rating || !form.title || !form.description || !form.author || !form.date || !form.category;

  const getRatingLabel = () => {
    const labels = ["", "แย่มาก", "แย่", "พอใช้", "ดี", "ดีมาก"];
    return form.rating > 0 ? labels[form.rating] : "";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f4eb] to-[#edf5ed] py-12 px-4">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <h1 className="text-3xl font-bold text-[#2b5d4a] mb-2 flex items-center">
          <FaPen className="mr-3 text-[#7ea566]" />
          เพิ่มรีวิวใหม่
        </h1>
        <p className="text-gray-700 mb-8">แชร์ประสบการณ์และความคิดเห็นของคุณ</p>

        {status && (
          <div
            className={`mb-6 p-4 rounded-lg flex items-center ${
              statusType === "success"
                ? "bg-green-50 text-green-800 border border-green-200"
                : "bg-red-50 text-red-800 border border-red-200"
            }`}
          >
            {statusType === "success" ? (
              <FaCheckCircle className="mr-2 text-green-500" />
            ) : (
              <div className="mr-2 text-red-500">⚠️</div>
            )}
            {status}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-[#f7fbf7] p-5 rounded-lg border border-[#e3ece5] mb-6">
            <h2 className="font-medium text-lg text-[#2b5d4a] mb-4">ข้อมูลรีวิว</h2>
            
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                <FaList className="mr-2 text-[#7ea566]" /> หัวข้อ
              </label>
              <input
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder="คุณกำลังรีวิวอะไร?"
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] transition-all text-black"
                required
              />
            </div>
            
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                <FaTags className="mr-2 text-[#7ea566]" /> หมวดหมู่
              </label>
              <select
                name="category"
                value={form.category}
                onChange={handleChange}
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] bg-white transition-all text-black"
                required
              >
                <option value="">เลือกหมวดหมู่</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                คะแนนของคุณ
              </label>
              {renderStarRating()}
              {form.rating > 0 && (
                <p className="text-sm text-[#2b5d4a] mt-1 font-medium">
                  {getRatingLabel()}
                </p>
              )}
            </div>
          </div>

          <div className="bg-[#f7fbf7] p-5 rounded-lg border border-[#e3ece5]">
            <h2 className="font-medium text-lg text-[#2b5d4a] mb-4">รายละเอียด</h2>
            
            <div className="mb-5">
              <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                รายละเอียดรีวิว
              </label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="แชร์ประสบการณ์ของคุณ..."
                rows="5"
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] transition-all text-black"
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                  <FaUser className="mr-2 text-[#7ea566]" /> ผู้เขียน
                </label>
                <input
                  type="text"
                  name="author"
                  value={form.author}
                  onChange={handleChange}
                  placeholder="ชื่อของคุณ"
                  className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] transition-all text-black"
                  required
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                  <FaCalendarAlt className="mr-2 text-[#7ea566]" /> วันที่
                </label>
                <input
                  type="date"
                  name="date"
                  value={form.date}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] transition-all text-black"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-800 flex items-center mb-2">
                <FaImage className="mr-2 text-[#7ea566]" /> รูปโปรไฟล์ (URL)
              </label>
              <input
                type="url"
                name="authorImg"
                value={form.authorImg}
                onChange={handleChange}
                placeholder="https://..."
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-[#7ea566] focus:border-[#7ea566] transition-all text-black"
              />
              <p className="text-xs text-gray-700 mt-1">
                ไม่ใส่ก็ได้ ระบบจะสร้างให้โดยอัตโนมัติ
              </p>
            </div>
          </div>

          <button
            type="submit"
            className={`w-full bg-[#2b5d4a] text-white px-6 py-3.5 rounded-lg hover:bg-[#1f4436] transition-colors font-medium shadow-md ${
              isSubmitDisabled ? "opacity-50 cursor-not-allowed" : "hover:shadow-lg"
            } flex justify-center items-center space-x-2`}
            disabled={isSubmitDisabled || isSubmitting}
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>กำลังส่ง...</span>
              </>
            ) : (
              <span>ส่งรีวิว</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}